package com.example.simplemsa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplemsaApplicationTests {

	@Test
	void contextLoads() {
	}

}
